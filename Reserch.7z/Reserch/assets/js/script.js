function openNav(){document.getElementById("mySidenav").style.width="250px",document.getElementById("main").style.marginLeft="250px"}function closeNav(){document.getElementById("mySidenav").style.width="0",document.getElementById("main").style.marginLeft="0"}$(function(){var e=document.getElementById("viewsample-img"),t=document.getElementById("viewsample-img2"),i=document.getElementById("popupform");window.onclick=function(s){s.target!=e&&s.target!=i&&s.target!=t||$("#viewsample-img,#viewsample-img2,#popupform").modal("hide")},$('input[type="text"], textarea').val().length>0&&$("fieldset").addClass("active"),$(".field input, .field textarea").blur(function(){""!=$(this).val()?$(this).closest(".field").find("fieldset").addClass("active"):$(this).closest(".field").find("fieldset").removeClass("active")}),$(".field input, .field textarea").focusin(function(){$(this).closest(".field").find("fieldset").addClass("active")}),$(".count").each(function(){$(this).prop("Counter",0).animate({Counter:$(this).text()},{duration:4e3,easing:"swing",step:function(e){$(this).text(Math.ceil(e))}})});var s=$(".side-form"),o=$(".side-click-area");s.css("right","-380px"),o.click(function(){s.hasClass("visiable")?s.animate({right:"-380px"},{duration:10}).removeClass("visiable"):s.animate({right:"0px"},{duration:10}).addClass("visiable")}),$(window).scroll(function(){$(window).scrollTop()>=300?$(".side-form").fadeIn("slow"):$(".side-form").fadeOut("slow")}),$("#sideform").intlTelInput({defaultCountry:"auto",nationalMode:!0,separateDialCode:!0,initialCountry:"auto"}),$("#popup .field.phone .number").intlTelInput({defaultCountry:"auto",nationalMode:!0,separateDialCode:!0,initialCountry:"auto"}),$(".testimonials").slick({arrows:!1,dots:!0,autoplay:!0,slidesToShow:2,slidesToScroll:2,autoplaySpeed:4e3,responsive:[{breakpoint:767,settings:{unslick:!0,slidesToShow:1,slidesToScroll:1}}]});var l={1:{slider:".xs-slider"}};$.each(l,function(){$(this.slider).slick({arrows:!1,dots:!0,autoplay:!1,slidesToShow:1,slidesToScroll:1,settings:"unslick",responsive:[{breakpoint:2e3,settings:"unslick"},{breakpoint:767,settings:{unslick:!0}}]})});l={1:{slider:".xs-slider-arrow"}};$.each(l,function(){$(this.slider).slick({arrows:!0,dots:!1,autoplay:!1,slidesToShow:1,slidesToScroll:1,settings:"unslick",responsive:[{breakpoint:2e3,settings:"unslick"},{breakpoint:767,settings:{unslick:!0}}]})}),$(".footer-top-bg ul.boxes>li h5 i").click(function(){$(this).closest("li").find("ul").slideToggle(),"+"==$(this).text()?$(this).text("-"):$(this).text("+")}),$(".reviews-testimonials").slick({arrows:!1,dots:!0,autoplay:!0,slidesToShow:1,slidesToScroll:1,autoplaySpeed:4e3,responsive:[{breakpoint:767,settings:{unslick:!0,slidesToShow:1,slidesToScroll:1}}]}),$("button.slick-arrow, .slick-dots li button").click(function(){setTimeout(function(){$(window).scrollTop($(window).scrollTop()+1).scrollTop($(window).scrollTop()-1)},400)})});



$(function () {
		var filterList = {
			init: function () {
				$('#portfoliolist').mixItUp({
  				selectors: {
    			  target: '.portfolio',
    			  filter: '.filter'	
    		  },
    		  load: {
      		  filter: '.all'  
      		}     
				});								
			
			}
		};
		filterList.init();
		
		
		
		
		
		
		
		
		
		
		
		
		
	var product_id = $('body').attr('id');
	setTimeout(function(){$('select[name="psrvc"] option[value="'+product_id+'"]').attr('selected','selected');},100)
	
	
	$("a.preview").prettyPhoto({social_tools: false});


setTimeout(function(){$('input[name="ctry"]').val($('.country-list li.active .country-name').html());},100);


$('body').delegate('.country','click',function(){
		$('input[name="pc"]').val($(this).find('.dial-code').text());
		var countryname = $(this).find('.country-name').text();
		var countryname2 = 	countryname.split("(");
		$('input[name="ctry"]').val(countryname2[0]);	
		});
	$("#phone, #sideform, #phoneside").intlTelInput({
		defaultCountry: "auto",
		nationalMode : true,
		 
    });
	
		
		
		
		
		
	/*					// popup //
	 $('.close-btn, .overlay1').on("click", function(){
		 $('.popup-img, .overlay1').fadeOut();
	 });
	 




			// popup //
	 $('.close-btn, .overlay1').on("click", function(){
		 $('.popup-img, .overlay1').fadeOut();
	 });
	 
	 $('.close-btn, .overlay1').on("click", function(){
		 $('.popup-img, .overlay1').fadeIn();
	 });
	 
	 	$('.close-btn, .overlay1').on("click", function(){
		$('.popup-img, .overlay1').remove();   	
	}); 
	
	if ($.cookie('cookie_form') == null)
			{
			setTimeout(function(){
					$('.popup-img, .overlay1').fadeIn();
				},500);
		 		
			  cokie();
			}		
		
		*/
		
		
		
		
	});	
	
	
	




/*function cokie(){
		$.cookie("cookie_form", 1,{
			expires : 1
			});
		var cookieValue = $.cookie("orform");
	
}
*/




































function breadcrumb(v){
// Breadcrumb start

var url = window.location.href, lnt=0,lnk,brd,txt,skp=0;
	url = url.split("?");
	url = url[0].replace("http://","");
	console.log('-'+url+'-');
	//url = url.trim();
	url = url.split("/");
	brd = '<div class="item">';
	//console.log(url.length);
	for(i=0;i<=url.length-v;i++){
		//console.log(i+' - '+url[i]);
		txt = url[i].replace(/-/g," ");
		if(url[i].length!=0 && skp==0){
			if(url[i]=="page"){skp=1;}else {
			if(i==0){
				brd = brd+'<a href="/">Home</a>';
				lnk = 'http://'+url[i]+'/';
			} else if(i >= 1){
						if(txt=="terms"){
						txt = "Terms of Service";
						}
						if(txt=="ordernow"){
						txt = "Student Area";
						}
				lnk = lnk+url[i]+'/';
				brd = brd+' > <a href="'+lnk+'">'+txt+'</a>';
			}}
		}
		
	}
	
	brd = brd+'</div>';
	
$('.breadcrumb').html(brd);
//set text limit on bread curmb 
$(".breadcrumb .item a").text(function(index, text) {
    return text.substr(0, 70);
});

// Breadcrump end
}